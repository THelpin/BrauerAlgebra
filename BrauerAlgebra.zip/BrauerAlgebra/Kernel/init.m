(* ::Package:: *)

Get["BrauerAlgebra/BrauerAlgebra.m"]
